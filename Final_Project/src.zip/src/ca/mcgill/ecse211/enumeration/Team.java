package ca.mcgill.ecse211.enumeration;
/** 
 * Enumeration for the Team's color  
 * 
 * @author Jeffrey Leung
 * @author Lea Akkary
 */
public enum Team {
	RED, GREEN
}
